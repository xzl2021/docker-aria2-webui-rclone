self.__precacheManifest = [
  {
    revision: "4eb7af0db693855a4f24cb119a73110d",
    url: "flags/de.svg"
  },
  {
    revision: "3b828f54c0e614e18db2c1816c9c2e84",
    url: "index.html"
  },
  {
    revision: "3b00bc3b62feafb50a2e",
    url: "vendor.js"
  },
  {
    revision: "8020fcd82cc09410f7bad1bc875c115a",
    url: "flags/es.svg"
  },
  {
    revision: "617c6a550519013aed310e0fe85bb088",
    url: "flags/us.svg"
  },
  {
    revision: "0f6e3867129940ef785c7c8720e0b56d",
    url: "flags/ru.svg"
  },
  {
    revision: "09ccf3b3b0a12dd5b3559acedc77858c",
    url: "flags/nl.svg"
  },
  {
    revision: "22084f478d0f401fa96288f7790ba8ef",
    url: "flags/tw.svg"
  },
  {
    revision: "4a936767fc2ac7335885d90b471d8629",
    url: "flags/pl.svg"
  },
  {
    revision: "60fb243496d39972a15bf5a78b6e50ee",
    url: "flags/tr.svg"
  },
  {
    revision: "a88d006ab7afa49d76ecd86dd1b11f77",
    url: "flags/th.svg"
  },
  {
    revision: "d5204a17fb30a59a4760b4109fbefe0b",
    url: "flags/it.svg"
  },
  {
    revision: "5e7a66fb0660b714f1a47859b90767e0",
    url: "flags/ir.svg"
  },
  {
    revision: "d107c3019844d2d1f0a4d179cbd8046e",
    url: "flags/id.svg"
  },
  {
    revision: "be1df903f0d7711ef8a4e96b6ca56dc0",
    url: "flags/fr.svg"
  },
  {
    revision: "5d1c62c220e3dcc85d70e206d44a9d4c",
    url: "flags/cz.svg"
  },
  {
    revision: "bedfd890b6c16afeb952546279242cf7",
    url: "flags/cn.svg"
  },
  {
    revision: "78de6acf30cc7fa4700207e205a52e88",
    url: "flags/br.svg"
  },
  {
    revision: "e1870e757b1b72d20d1f",
    url: "app.js"
  },
  {
    revision: "e1870e757b1b72d20d1f",
    url: "app.css"
  }
];
